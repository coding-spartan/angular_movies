import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { observable } from 'rxjs';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-movieinfo',
  templateUrl: './movieinfo.component.html',
  styleUrls: ['./movieinfo.component.css']
})


export class MovieinfoComponent implements OnInit {
  movie: any;
  movies = [];
 
  constructor(private _httpService: HttpService, private _route:ActivatedRoute, private _router: Router,) { }

  ngOnInit() {
    this.movie = {};

    this._route.params.subscribe((params: Params) => 
    {let observable = this._httpService.getMovie(params["id"]);
      observable.subscribe(data => {
        console.log(data);
        if(data["message"] == "Success") {
        this.movie = data["movie"]

          }
        })
      })
    }
      
// getPet(id) {
//   let observable = this._httpService.getPet(id);
//   observable.subscribe(data => {
//   if(data["message"] == "Success") {
//   this.pet = data["pet"]
//     }
//   });
// }
  
// getPets() {
//   let observable = this._httpService.getPets();
//   observable.subscribe(data => {
//   if(data["message"] == "Success") {
//   this.pets = data["data"]
//   }
//   });
//   }

  deleteMovie(id: string) {
    let observable = this._httpService.deleteMovie(id);
    observable.subscribe(data => {
    console.log("deleted!", data);
    if (data['message'] == "Success") {
      this._router.navigate(['/'])
     }
    else{
      console.log("Not updated", data['error'])
     }
  });
}

}

