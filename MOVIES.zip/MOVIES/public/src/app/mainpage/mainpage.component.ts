import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
// import { observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})

export class MainpageComponent implements OnInit {
  movies = [];

  constructor(
    private _httpService: HttpService,
    private _route: ActivatedRoute,
    private _router: Router
    ) { }

ngOnInit() {
this.getMovies();
}

getMovies() {
let observable = this._httpService.getMovies();
observable.subscribe(data => {
if(data["message"] == "Success") {
this.movies = data["movie"]
console.log(data)
}
});
}

// deleteMovie(id) {
//   let observable = this._httpService.deleteMovie(id);
//   observable.subscribe(data => {
//   console.log("deleted!", data);
//   if (data['message'] == "Success") {
//     this.getMovies()
//    }
//   else{
//     console.log("Not updated", data['error'])
//    }
// });
// }


}
