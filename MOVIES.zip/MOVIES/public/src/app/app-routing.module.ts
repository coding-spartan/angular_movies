import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainpageComponent } from './mainpage/mainpage.component';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { MovieinfoComponent } from './movieinfo/movieinfo.component';

const routes: Routes = [
{path: "", pathMatch: "full", component: MainpageComponent},
{path: "add", component: AddComponent},
{path: "edit/:id", component: EditComponent},
{path: "movieinfo/:id", component: MovieinfoComponent},
{path: "**", component: MainpageComponent  }
];

@NgModule({
imports: [RouterModule.forRoot(routes)],
exports: [RouterModule]
})
export class AppRoutingModule { }











