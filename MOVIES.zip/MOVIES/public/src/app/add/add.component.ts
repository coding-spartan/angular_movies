import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
new_movie = {title: "", user: "", stars: "", review: ""};//not sure about stars??
errors = null;

constructor(
private _httpService: HttpService,
private _router: Router
) { }

ngOnInit() {
this.new_movie= {title: "", user: "", stars:"", review: ""};
}

addMovie() {
let observable = this._httpService.addMovie(this.new_movie);
observable.subscribe(data => {
if(data["message"] == "Success") {
this.new_movie = {title: "", user: "", stars:"", review:""};
this._router.navigate(["/"]);
}
else {
this.errors = data["error"];
console.log(this.errors);
}
});
}

}
