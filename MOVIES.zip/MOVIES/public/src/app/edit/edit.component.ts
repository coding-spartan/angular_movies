import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})


export class EditComponent implements OnInit {
id: string;
private sub: any;
// user = {user: ""};
// review = {review: ""};
// stars = {starts: ""}; ///this might not work
errors: null;
movie: any;

constructor(
private _httpService: HttpService,
private _route: ActivatedRoute,
private _router: Router
) { }

// ngOnInit() {
// this.sub = this._route.params.subscribe(params => {
// this.id = params["id"];
// this.getPet();
// });
// }

ngOnInit() {
  this.movie = {};
  this._route.params.subscribe((params: Params) => 
  {let observable = this._httpService.getMovie(params["id"]);
    observable.subscribe(data => {
      console.log(data);
      if(data["message"] == "Success") {
      this.movie = data["movie"]
        }
      })
    })
  }





// getPet() {
// this._httpService.getPet(this.id).subscribe(data => {
// console.log(data);
// if(data["message"] == "Success") {
// this.pet = data["data"];
// }
// });
// }

updateMovie(id) {
this._httpService.updateMovie(id, this.movie).subscribe(data => {
if(data["message"] == "Success") {
this._router.navigate(['/movieinfo', id]);
}
else {
this.errors = data["error"];
}
});
}

}