import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class HttpService {
  constructor(private _http: HttpClient){
  }

getMovies(){
  return this._http.get('/movies');
  };

getMovie(id){
  return this._http.get('/movies/'+id)
};

addMovie(newMovie){
  return this._http.post('/movies/new', newMovie)
};

updateMovie(id, selectedMovie){
  return this._http.put(`/movies/${id}/review`, selectedMovie)
};

deleteMovie(id){
 return this._http.delete(`/movies/${id}/delete`)
};

}
